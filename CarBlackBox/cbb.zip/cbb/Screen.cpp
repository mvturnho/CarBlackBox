/*
 * Screen.cpp
 *
 *  Created on: 23 dec. 2014
 *      Author: m.vanturnhout
 */

#include "Screen.h"

Screen::Screen() {
	// TODO Auto-generated constructor stub

}

Screen::~Screen() {
	// TODO Auto-generated destructor stub
}

