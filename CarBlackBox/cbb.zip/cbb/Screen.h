/*
 * Screen.h
 *
 *  Created on: 23 dec. 2014
 *      Author: m.vanturnhout
 */

#ifndef SCREEN_H_
#define SCREEN_H_

class Screen {
public:
	Screen();
	virtual ~Screen();
};

#endif /* SCREEN_H_ */
