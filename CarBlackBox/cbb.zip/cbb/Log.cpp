/*
 * Log.cpp
 *
 *  Created on: 23 dec. 2014
 *      Author: m.vanturnhout
 */

#include "Log.h"

Log::Log() {
	// TODO Auto-generated constructor stub

}

Log::~Log() {
	// TODO Auto-generated destructor stub
}

