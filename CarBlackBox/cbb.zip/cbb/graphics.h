/*
 * graphics.h
 *
 *  Created on: 22 dec. 2014
 *      Author: mvturnho
 */

#ifndef CBB_GRAPHICS_H_
#define CBB_GRAPHICS_H_

#define SPEED_POS 40
#define RPM_POS 105
#define LOAD_POS 160
#define THR_POS  175
#define INFO_POS 200
#define BOTTOM_LINE 300
#define ALIGN_Y 2
#define ERROR_POS_X 120
#define ERROR_POS_Y 300
#define INIT_LOG_POS 150

#define COLD  	10
#define FROOZEN  20
#define CENTER_X 75
#define CENTER_Y 90
#define MAX_R	65
#define TOP  (CENTER_Y - MAX_R)
#define SIDE (CENTER_X - MAX_R)
#define WIDTH ((2*MAX_R)+SIDE)
#define HEIGHT ((2*MAX_R)+TOP)

#define BARHEIGHT  	7
#define STARTX 		155
#define MAXBAR		240
#define MAXSIGNAL   50.0
#define BARLENGTH   (MAXBAR - STARTX)
#define FACTOR 		(BARLENGTH / MAXSIGNAL)

//For Satelites screen
#define MAX_SATELLITES 40

// Color definitions
#define	BLACK   0x0000
#define	BLUE    0x001F
#define	DBLUE   0x000F
#define	RED     0xF800
#define	DRED    0xA900
#define	DGREEN  0x0300
#define	GREEN   0x07E0
#define CYAN    0x07FF
#define MAGENTA 0xF81F
#define YELLOW  0xFFE0
#define WHITE   0xFFFF
#define BRIGHT_RED	0xf810
#define GRAY1		0x8410
#define GRAY2		0x4208

extern TFT_ILI9340 tft;
typedef struct satelite {
	bool active;
	int elevation;
	int azimuth;
	int snr;
	int run;
	int old_x;
	int old_y;
} Sat;

satelite sats[MAX_SATELLITES];

extern TinyGPSPlus gps;
extern float gpsangle;
extern bool has_sd;
extern bool blink;
extern char fileName[];

extern int rpm;
extern int obdspeed;
extern int load;
extern int throttle;
extern int frp;
extern int maf;
extern int temp;

static void print_int(unsigned int val, bool valid, int len) {
//	clearLine(0);
	char sz[32];
	if (!valid)
		strcpy(sz, "*******");
	else
		sprintf(sz, "%d", val);
	sz[len] = 0;
	for (int i = strlen(sz); i < len; ++i)
		sz[i] = ' ';
	if (len > 0)
		sz[len - 1] = ' ';
	tft.println(sz);
//	feedgps();
}

static void print_fixint(unsigned long val, bool valid, int len) {
//	clearLine(0);
	char sz[32];
	if (!valid)
		strcpy(sz, "*******");
	else
		sprintf(sz, "%4d", val);
	sz[len] = 0;
	for (int i = strlen(sz); i < len; ++i)
		sz[i] = ' ';
	if (len > 0)
		sz[len - 1] = ' ';
	tft.println(sz);
//	feedgps();
}

static void print_float(float val, bool valid, int len, int prec) {
//	clearLine(0);
	char sz[32];
	if (!valid) {
		strcpy(sz, "............");
		sz[len] = 0;
		if (len > 0)
			sz[len - 1] = ' ';
		for (int i = 7; i < len; ++i)
			sz[i] = ' ';
		tft.print(sz);
	} else {
//		file.print(",");
//		file.print(val, prec);
		tft.print(val, prec);
		int vi = abs((int) val);
		int flen = prec + (val < 0.0 ? 2 : 1);
		flen += vi >= 1000 ? 4 : vi >= 100 ? 3 : vi >= 10 ? 2 : 1;
		for (int i = flen; i < len; ++i)
			tft.print(" ");
	}

	tft.println();
//	feedgps();
}

static void print_date(TinyGPSPlus &gps) {
//	TinyGPSDate d = gps.date;
//	TinyGPSTime t = gps.time;
//	if (!d.isValid()) {
//		tft.print("../../....");
//	} else {
		char sz[32];
		sprintf(sz, "%02d/%02d/%02d",  day(), month(), year());
		tft.print(sz);
//	}
	tft.print("  ");
//	if (!t.isValid()) {
//		tft.print("..:..:..");
//	} else {
//		char sz[32];
		sprintf(sz, "%02d:%02d:%02d", hour(), minute(), second());
		tft.print(sz);
//	}

//	feedgps();
}

static void print_str(const char *str, int len) {
//	clearLine(len * 5);

	int slen = strlen(str);
	for (int i = 0; i < len; ++i)
		tft.println(i < slen ? str[i] : ' ');
//	feedgps();
}

void drawSourceIndicator(int xpos, int ypos, const char *str, int fg_color,
		int bg_color) {
	tft.setCursor(xpos, ypos);
	tft.setTextColor(fg_color, bg_color);
//	tft.setTextSize(2);
	tft.print(str);
}

void drawSDCardFileMessage() {
//	tft.setTextSize(1);
	if (has_sd)
		tft.setTextColor(WHITE, BLACK);
	else {
		if (blink)
			tft.setTextColor(RED, BLACK);
		else
			tft.setTextColor(BLACK, BLACK);
	}
//	tft.setCursor(0, ERROR_POS_Y);
	tft.print(fileName);
}

void drawDot(int i, int offset, int color) {
	//first delete the old
	tft.fillCircle(sats[i].old_x, sats[i].old_y, 3, BLACK);
	tft.setTextColor(BLACK);
//	tft.setTextSize(1);
	tft.setCursor(sats[i].old_x, sats[i].old_y + 4);
	tft.print(i + 1);
	//draw the new
	int fact = ((float) sats[i].elevation / 90) * MAX_R;
	int y = fact * sin(radians(sats[i].azimuth + offset));
	int x = fact * cos(radians(sats[i].azimuth + offset));
	tft.fillCircle(CENTER_X + x, CENTER_Y + y, 2, color);
	tft.setTextColor(color);
//	tft.setTextSize(1);
	tft.setCursor(CENTER_X + x, CENTER_Y + y + 4);
	tft.print(i + 1);
	sats[i].old_x = CENTER_X + x;
	sats[i].old_y = CENTER_Y + y;
}

void drawOpenDot(float angle, int offset, float r, int color,
		int c_color = -1) {
	int fact = (r / 90) * MAX_R;
	int y = fact * sin(radians(angle + offset));
	int x = fact * cos(radians(angle + offset));
	tft.drawCircle(CENTER_X + x, CENTER_Y + y, 3, color);
	if (c_color > -1)
		tft.fillCircle(CENTER_X + x, CENTER_Y + y, 2, c_color);
	else
		tft.drawCircle(CENTER_X + x, CENTER_Y + y, 2, color);
}

void drawBar(int i, int color) {
	if (sats[i].snr > 0) {
		int y = i * 8;
		int w = sats[i].snr * FACTOR;
		if (color == BLACK) {
			tft.fillRect(STARTX, y, MAXBAR, BARHEIGHT, BLACK);
		} else {
			tft.fillRect(STARTX, y, w, BARHEIGHT, color);
			tft.fillRect(STARTX + w, y, BARLENGTH - w, BARHEIGHT,
					BLACK);

			tft.setTextColor(WHITE);
			tft.setCursor(MAXBAR - 14, y);
			tft.setTextSize(1);
			tft.print(i + 1);
		}
	}
}

void drawPercentBar(int value, int y, int color, const char *label) {
	int lx = 2.4 * value;
	tft.fillRect(0, y, lx, 10, color);
	tft.fillRect(lx, y, 240 - lx, 10, BLACK);
//	tft.setCursor(2, y + 1);
//	tft.setTextSize(1);
//	tft.setTextColor(WHITE);
//	tft.print(label);
//	tft.setCursor(40, y + 1);
//	print_fixint(value, -1, 6);
//	feedgps();
}

void drawRealTimeData() {
	drawPercentBar(load, LOAD_POS, DGREEN, "load:");
	drawPercentBar(throttle, THR_POS, YELLOW, "throttle:");
}

void rotatePoint(float a, int *x, int *y, int xm, int ym) {
	// Subtract midpoints, so that midpoint is translated to origin
	// and add it in the end again
	int xr = (*x - xm) * cos(a) - (*y - ym) * sin(a) + xm;
	int yr = (*x - xm) * sin(a) + (*y - ym) * cos(a) + ym;
	//result values
	*x = xr;
	*y = yr;
}

void drawSatScreen() {
	tft.fillScreen(BLACK);
//	tft.setCursor(0, 260);
	tft.fillRoundRect(0, 260, STARTX - 10, 60, 10, DRED);
}

#endif /* CBB_GRAPHICS_H_ */
